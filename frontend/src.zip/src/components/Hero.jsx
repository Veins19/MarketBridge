// src/components/Hero.jsx
import React from 'react';
import './Hero.css';

const Hero = ({ onStart }) => {
    return (
        <section className="hero">
            <h1 className="hero-title">MarketBridge</h1>
            <p className="hero-subtitle">
                AI-Powered Market Strategy Platform — Plan campaigns, manage inventory, optimize finance.
            </p>
            <button className="hero-btn" onClick={onStart}>
                Get Started
            </button>
        </section>
    );
};

export default Hero;

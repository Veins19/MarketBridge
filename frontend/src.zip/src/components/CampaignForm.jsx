// src/components/CampaignForm.jsx
import React, { useState } from 'react';
import './Hero.css'; // Reuse Hero.css for inputs/buttons

const CampaignForm = ({ onSubmit }) => {
    const [query, setQuery] = useState('');
    const [product, setProduct] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(query, product);
    };

    return (
        <form className="hero-form" onSubmit={handleSubmit}>
            <input
                type="text"
                className="input-field"
                placeholder="Enter campaign request"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
            />
            <input
                type="text"
                className="input-field"
                placeholder="Enter product name"
                value={product}
                onChange={(e) => setProduct(e.target.value)}
            />
            <button className="hero-btn" type="submit">
                Submit
            </button>
        </form>
    );
};

export default CampaignForm;

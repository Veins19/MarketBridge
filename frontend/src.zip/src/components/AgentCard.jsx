// src/components/AgentCard.jsx
import React from 'react';
import './AgentSection.css';

const AgentCard = ({ title, content }) => {
    return (
        <div className="agent-card">
            <h3>{title}</h3>
            <p>{content}</p>
        </div>
    );
};

export default AgentCard;

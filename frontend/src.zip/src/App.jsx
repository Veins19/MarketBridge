// src/App.jsx
import React, { useState } from 'react';
import Hero from './components/Hero';
import CampaignForm from './components/CampaignForm';
import AgentCard from './components/AgentCard';
import { runAgents } from './api';

const App = () => {
    const [started, setStarted] = useState(false);
    const [responses, setResponses] = useState(null);

    const handleStart = () => setStarted(true);

    const handleSubmit = async (query, product) => {
        const result = await runAgents(query, product);
        setResponses(result);
    };

    return (
        <div>
            {!started ? (
                <Hero onStart={handleStart} />
            ) : (
                <div style={{ padding: '2rem', maxWidth: '800px', margin: '0 auto' }}>
                    <CampaignForm onSubmit={handleSubmit} />
                    {responses &&
                        Object.keys(responses).map((key) => (
                            <AgentCard key={key} title={key} content={responses[key]} />
                        ))}
                </div>
            )}
        </div>
    );
};

export default App;
